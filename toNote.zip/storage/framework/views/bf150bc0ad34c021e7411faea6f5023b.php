<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>


        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-xl-5">
                    <div class="card card-body mt-4 mb-5">

                        <h4 class="text-center mb-5"><b>REGISTER</b></h4>

                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" class="form-control" required autofocus autocomplete="username" />
                            <div class="formErr"><?php echo e($errors->first('name')); ?></div>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" class="form-control" required autofocus autocomplete="username" />
                            <div class="formErr"><?php echo e($errors->first('email')); ?></div>
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" id="password" value="<?php echo e(old('password')); ?>" class="form-control" required autocomplete="current-password" />
                            <div class="formErr"><?php echo e($errors->first('password')); ?></div>
                        </div>

                        <div class="form-group">
                            <label for="password_confirmation">Confirm Password</label>
                            <input type="password" name="password_confirmation" id="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" class="form-control" required autocomplete="new-password" />
                            <div class="formErr"><?php echo e($errors->first('password_confirmation')); ?></div>
                        </div>


                        <div class="text-right">
                            <a class="text-dark" href="<?php echo e(route('login')); ?>"><small>Already registered?</small></a>
                        </div>

                        <div class="text-center mt-4">
                            <button class="btn btn-primary">Register</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </form>





 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\toNote\resources\views/auth/register.blade.php ENDPATH**/ ?>