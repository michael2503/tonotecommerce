<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.success-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('success-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.error-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <section class="breadCrum">
        <div class="container">
            <div class="breacrumCard">
                Shopping Cart
            </div>
        </div>
    </section>


    <section id="cartsPage">

        <div class="container">
            <div class="cart-wrapper">

                <div class="row">
                    <div class="info-block col-lg-8 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead class="thead-dark tHead">
                                      <tr>
                                        <th class="text-left">Item Details</th>
                                        <th class="text-left">Quantity</th>
                                        <th class="text-left">Item Price</th>
                                        <th class="text-left">Action</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                        <?php $total = 0; ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php $total += $details['product']['sales_price'] * $details['qty'] ?>
                                        <tr class="eachCart">
                                            <td>
                                                <div class="firstCol d-flex justify-content-start">
                                                    <div class="proImg">
                                                        <?php $imgLink = $details['product']['images']; ?>
                                                        <img src='<?php echo e(asset("assets/images/products/$imgLink")); ?>' alt="">
                                                    </div>
                                                    <div class="proInfo">
                                                        <p class="title"><?php echo e($details['name']); ?></p>
                                                        <p class="subTtitle text-muted">Category: <?php echo e($details['product']['category']); ?></p>
                                                        <p class="subTtitle text-muted">SKU: <?php echo e($details['product']['sku']); ?></p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="text-left">
                                                <div class="desInc">
                                                    <a href="<?php echo e(route('removeFromCart', $details['product_id'])); ?>"><span class="pointer">-</span></a>
                                                    <span><?php echo e($details['qty']); ?></span>
                                                    <a href="<?php echo e(route('addToCart', $details['product_id'])); ?>"><span class="pointer">+</span></a>
                                                </div>
                                            </td>
                                            <td class="text-left">
                                                <div class="price">
                                                    <p class="amount">₦<?php echo e(number_format($details['qty'] * $details['product']['sales_price'])); ?></p>
                                                    <p class="amtDesc">₦<?php echo e(number_format( $details['product']['sales_price'])); ?> x <?php echo e($details['qty']); ?> items</p>
                                                </div>
                                            </td>
                                            <td>
                                                <a class="btn btn-sm btn-danger" href="<?php echo e(route('deleteCart', $details['product_id'])); ?>"><i class="fa fa-trash"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">
                                                <div class="mb-4">
                                                    No Carts
                                                </div>
                                                <a href="<?php echo e(route('productListings')); ?>" class="btn btn-success rounded-0">Start Shopping</a>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>



                    <div class="info-block col-lg-4 col-md-6 col-sm-12">
                        <div class="inner">
                            <div class="card">
                                <div class="text-left card-header">
                                    Order Summary
                                </div>
                                <div class="card-body p-0 orderSumm">
                                    <div class="d-flex justify-content-between">
                                        <div>Sub Total</div>
                                        <div>₦<?php echo e(number_format($total)); ?></div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div>Shipping Fee</div>
                                        <div>₦0</div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div><b>Total</b></div>
                                        <div><b>₦<?php echo e(number_format($total)); ?></b></div>
                                    </div>
                                    <?php if($total > 0): ?>
                                    <div class="mt-5 mb-4 text-center">
                                        <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary rounded-0">Proceed to Checkout</a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </section>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\toNote\resources\views/guest/carts.blade.php ENDPATH**/ ?>