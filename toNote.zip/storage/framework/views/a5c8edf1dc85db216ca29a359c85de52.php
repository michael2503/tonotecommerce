<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.success-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('success-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.error-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <section class="breadCrum">
        <div class="container">
            <div class="breacrumCard">
                Checkout
            </div>
        </div>
    </section>


    <section id="cartsPage">

        <div class="container">
            <div class="cart-wrapper">

                <div class="row">
                    <div class="info-block col-lg-4 col-md-6 col-sm-12">
                        <div class="inner">
                            <div class="card">
                                <div class="text-left card-header">
                                    Order Summary
                                </div>
                                <div class="card-body p-0 orderSumm">
                                    <div class="d-flex justify-content-between">
                                        <div>Sub Total</div>
                                        <div>₦<?php echo e(number_format($total)); ?></div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div>Shipping Fee</div>
                                        <div>₦0</div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div><b>Total</b></div>
                                        <div><b>₦<?php echo e(number_format($total)); ?></b></div>
                                    </div>
                                    <?php if($total > 0): ?>
                                    <div class="mt-5 mb-4 text-center">
                                        <a href="<?php echo e(route('viewCartList')); ?>" class="btn btn-primary rounded-0">Back to Cart</a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="info-block col-lg-8 col-md-6 col-sm-12">
                        <div class="inner">
                            <div class="card">
                                <div class="text-left card-header">
                                    Order Summary
                                </div>
                                <div class="card-body p-3 orderSumm">
                                    <form method="POST" action="<?php echo e(route('createOrder')); ?>">
                                        <?php echo csrf_field(); ?>

                                        <div class="checkSec">
                                            <div class="checkTitle">
                                                Personal Info
                                            </div>

                                            <div class="form-wrap">
                                                <div class="row">
                                                    <div class="col-xl-6 col-lg-6">
                                                        <div class="form-group ">
                                                            <label for="first_name">First Name</label>
                                                            <input type="text" class="form-control" name="first_name" required value="<?php echo e(old('first_name')); ?>">
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-6 col-lg-6">
                                                        <div class="form-group ">
                                                            <label for="last_name">Last Name</label>
                                                            <input type="text" class="form-control" name="last_name" required value="<?php echo e(old('last_name')); ?>">
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-6 col-lg-6">
                                                        <div class="form-group ">
                                                            <label for="email">Email</label>
                                                            <input type="email" class="form-control" name="email" required value="<?php echo e(old('email')); ?>">
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-6 col-lg-6">
                                                        <div class="form-group ">
                                                            <label for="phone">Phone Number</label>
                                                            <input type="text" class="form-control" name="phone" required value="<?php echo e(old('phone')); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="checkSec">
                                            <div class="checkTitle">
                                                Shipping Address
                                            </div>

                                            <div class="form-wrap">
                                                <div class="row">
                                                    <div class="col-xl-12 col-lg-12">
                                                        <div class="form-group ">
                                                            <label for="address">Address</label>
                                                            <input type="text" class="form-control" name="address" required value="<?php echo e(old('address')); ?>">
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-6 col-lg-6">
                                                        <div class="form-group ">
                                                            <label for="bus_stop">Nearest Bus-stop</label>
                                                            <input type="text" class="form-control" name="bus_stop" required value="<?php echo e(old('bus_stop')); ?>">
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-6 col-lg-6">
                                                        <div class="form-group ">
                                                            <label for="city">City</label>
                                                            <input type="text" class="form-control" name="city" required value="<?php echo e(old('city')); ?>">
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-6 col-lg-6">
                                                        <div class="form-group ">
                                                            <label for="state">State</label>
                                                            <input type="text" class="form-control" name="state" required value="<?php echo e(old('state')); ?>">
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-6 col-lg-6">
                                                        <div class="form-group ">
                                                            <label for="country">Country</label>
                                                            <input type="text" class="form-control" name="country" required value="<?php echo e(old('country')); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="checkSec">
                                            <div class="checkTitle">
                                                Payment Method
                                            </div>

                                            <div class="form-wrap">
                                                <div class="custom-control custom-checkbox mb-4">
                                                    <input type="checkbox" class="custom-control-input" value="Delivery" id="payDelivery" name="payment_method">
                                                    <label class="custom-control-label" for="payDelivery">Pay on Delivery</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" value="Card" id="payCard" name="payment_method">
                                                    <label class="custom-control-label" for="payCard">Pay With Credit Card</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="mt-5 text-center">
                                            <button class="btn btn-primary">Checkout Now</button>
                                        </div>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </section>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\toNote\resources\views/user/checkout.blade.php ENDPATH**/ ?>