<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.success-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('success-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.error-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <style>

.shippingFee{
    border-bottom: 1px solid #ccc;
}
.shippingFee p{
    font-size: 14px;
}
.orderInfo p{
    font-size: 14px;
}
.orderInfo .shippingAddr{
    background: #f2f2f2;
    border: 1px solid #ccc;
    padding: 10px;
    margin-bottom: 15px;
}


@media only screen and (max-width: 400px){
    .proDetBody{
        padding: 5px;
    }
}
    </style>


    <section class="breadCrum">
        <div class="container">
            <div class="breacrumCard">
                Order #<?php echo e($order->order_number); ?>

            </div>
        </div>
    </section>


    <section id="cartsPage">

        <div class="container">
            <div class="cart-wrapper">

                <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-12 mt-2 mb-5">
                        <div class="card cardShadow">
                            <div class="card-header">
                                Order Info
                            </div>
                            <div class="card-body orderInfo p-2">
                                <div class="d-flex justify-content-between">
                                    <p>Order Number</p>
                                    <p><?php echo e($order->order_number); ?></p>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <p>Payment Method</p>
                                    <p><?php echo e($order->payment_method); ?></p>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <p>First Name</p>
                                    <p><?php echo e($order->first_name); ?></p>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <p>Last Name</p>
                                    <p><?php echo e($order->last_name); ?></p>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <p>Email</p>
                                    <p><?php echo e($order->email); ?></p>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <p>Phone</p>
                                    <p><?php echo e($order->phone); ?></p>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <p>Status</p>
                                    <p>
                                        <?php if($order->status == 'Pending'): ?>
                                        <span class="badge badge-info ml-2">Pending</span>
                                        <?php elseif($order->status == 'Delivered'): ?>
                                        <span class="badge badge-success ml-2">Delivered</span>
                                        <?php elseif($order->status == 'Cancelled'): ?>
                                        <span class="badge badge-danger ml-2">Cancelled</span>
                                        <?php elseif($order->status == 'Returned'): ?>
                                        <span class="badge badge-dark ml-2">Returned</span>
                                        <?php elseif($order->status == 'Shipped'): ?>
                                        <span class="badge badge-warning ml-2">Shipped</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <div class="d-block shippingAddr">
                                    <p>Shipping Address</p>
                                    <p class="mb-0">
                                        <?php echo e($order->address); ?>, <?php echo e($order->city); ?>, <?php echo e($order->bus_stop); ?> <?php echo e($order->state); ?>, <?php echo e($order->country); ?>

                                    </p>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <p>Order On</p>
                                    <p><?php echo e(date('M d, Y', strtotime($order->created_at))); ?></p>
                                </div>
                                <div class="text-center mt-3 mb-3">
                                    <a href="<?php echo e(route('downloadInvoice', $order->order_number)); ?>" class="btn btn-success btn-sm">Download Invoice</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-8 col-lg-8 col-md-12 mt-2 mb-5">
                        <div class="card cardShadow">
                            <div class="card-header">
                                Order Products
                            </div>
                            <div class="card-body proDetBody">
                                <?php $__currentLoopData = json_decode($order->product_json); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div *ngFor="let prod of products" class="eachOrder">
                                    <div class="row">
                                        <div class="col-xl-2 col-lg-3 col-md-3 col-sm-3 col-3">
                                            <div class="proImg">
                                                <img src='<?php echo e(asset("assets/images/products/$prod->images")); ?>' alt="">
                                            </div>
                                        </div>
                                        <div class="col-xl-10 col-lg-9 col-md-9 col-sm-9 col-9 proInfoWrapepr">
                                            <div class="proInfo">
                                                <p class="mb-0 proName"><?php echo e($prod->product_name); ?></p>
                                                <p class="pInfo mb-0 mt-2">Qty: <?php echo e($prod->qty); ?></p>
                                                <div class="priceSide">
                                                    <p class="amt mb-2">Amount:  <span>₦<?php echo e(number_format($prod->sales_price)); ?></span></p>
                                                    <p class="amt">Sub Total:  <span>₦<?php echo e(number_format($prod->sub_total)); ?></span></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <div class="d-flex justify-content-between mt-3 shippingFee">
                                    <p>Shipping Fee</p>
                                    <p>₦0.00</p>
                                </div>

                                <div class="d-flex justify-content-between mt-3">
                                    <p><b>Total</b></p>
                                    <p><b>₦<?php echo e(number_format($order->total)); ?></b></p>
                                </div>
                                <div *ngIf="order?.couponInfo" class="d-flex justify-content-between mt-3">
                                    <p><b>Total Paid</b></p>
                                    <p><b>₦<?php echo e(number_format($order->total)); ?></b></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </section>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\toNote\resources\views/user/orders-details.blade.php ENDPATH**/ ?>