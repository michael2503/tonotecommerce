<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.success-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('success-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.error-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>


    <section class="breadCrum">
        <div class="container">
            <div class="breacrumCard">
                My Orders
            </div>
        </div>
    </section>


    <section id="cartsPage">

        <div class="container">
            <div class="cart-wrapper">

                <div class="card cardShadow mb-5">
                    <div class="card-body">

                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <?php
                            $proInfo = json_decode($order->product_json)[0];
                        ?>

                        <div class="eachOrder">
                            <div class="row">
                                <div class="col-xl-3 col-lg-4 col-md-4 col-sm-4">
                                    <div class="proImg">
                                        <img src='<?php echo e(asset("assets/images/products/$proInfo->images")); ?>' alt="">
                                    </div>
                                </div>
                                <div class="col-xl-9 col-lg-8 col-md-8 col-sm-8 proInfoWrapepr">
                                    <div class="proInfo">
                                        <p><?php echo e($proInfo->product_name); ?></p>
                                        <p class="pInfo">Order Number: <?php echo e($order->order_number); ?></p>
                                        <p class="pInfo">Order On: <?php echo e(date('M d, Y', strtotime($order->created_at))); ?>

                                            <?php if($order->status == 'Pending'): ?>
                                            <span class="badge badge-info ml-2">Pending</span>
                                            <?php elseif($order->status == 'Delivered'): ?>
                                            <span class="badge badge-success ml-2">Delivered</span>
                                            <?php elseif($order->status == 'Cancelled'): ?>
                                            <span class="badge badge-danger ml-2">Cancelled</span>
                                            <?php elseif($order->status == 'Returned'): ?>
                                            <span class="badge badge-dark ml-2">Returned</span>
                                            <?php elseif($order->status == 'Shipped'): ?>
                                            <span class="badge badge-warning ml-2">Shipped</span>
                                            <?php endif; ?>
                                        </p>
                                        <div class="d-flex justify-content-between mt-3">
                                            <p class="pInfo">Total: ₦<?php echo e(number_format($order->total)); ?></p>
                                            <h5><a href="<?php echo e(route('orderDetails', $order->order_number)); ?>"><small><b>Order Details</b></small></a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-center">No Order</p>
                        <?php endif; ?>


                    </div>
                </div>

            </div>
        </div>

    </section>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\toNote\resources\views/user/orders.blade.php ENDPATH**/ ?>