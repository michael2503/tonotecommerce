<?php if(Session::get('success')): ?>
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-xl-6">
                <div class="mt-4 alert alert-success">
                    <b><?php echo e(Session::get('success')); ?></b>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Laravel\toNote\resources\views/components/success-message.blade.php ENDPATH**/ ?>