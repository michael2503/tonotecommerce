<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.success-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('success-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.error-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <section class="breadCrum">
        <div class="container">
            <div class="breacrumCard">
                Home <i class="fa fa-arrow-right"></i> Products
            </div>
        </div>
    </section>


    <section id="contentSide">
        <div class="container">
            <div class="proList">
                <div class="row">
                    <div class="col-xl-3">
                        <div class="card">
                            <div class="card-header">
                                Filter
                            </div>

                            <div class="card-body" style="height: 400px">

                            </div>
                        </div>

                        <div class="ads">
                            <div class="adsImg mt-4">
                                <img src="<?php echo e(asset("assets/images/banner_08.png")); ?>" alt="" width="100%">
                                <img src="<?php echo e(asset("assets/images/banner_06.avif")); ?>" class="mt-4" alt="" width="100%">
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-9">
                        <div class="card card-body">
                            <h2 class="catName">Category</h2>

                            <div class="sortSide">
                                <div class="d-flex justify-content-between">
                                    <div class="sortList">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-primary"><i class="fa fa-bars"></i></button>
                                            <button type="button" class="btn btn-primary"><i class="fa fa-th"></i></button>
                                        </div>
                                    </div>
                                    <div class="sortFiled">
                                        <span>
                                            Sort:
                                            <select name="" id="">
                                                <option value="">Aphabetically A-Z</option>
                                                <option value="">Aphabetically Z-A</option>
                                                <option value="">Price: High - Low</option>
                                                <option value="">Price: Low - High</option>
                                                <option value="">Date: New - Old</option>
                                                <option value="">Date: Old - New</option>
                                            </select>
                                        </span>
                                    </div>
                                </div>
                            </div>


                            <div class="product-list">
                                <div class="row">
                                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-xl-3">
                                        <div class="eachList">
                                            <div class="proImg">
                                                <img src='<?php echo e(asset("assets/images/products/$product->images")); ?>' alt="">
                                            </div>
                                            <p class="proName"><?php echo e($product->name); ?></p>
                                            <p class="proPrice">
                                                <?php if($product->old_price > 0): ?>
                                                <span class="oldPrice">₦<?php echo e(number_format($product->old_price)); ?></span>
                                                <?php endif; ?>
                                                <span class="salesPrice">₦<?php echo e(number_format($product->sales_price)); ?></span>
                                            </p>

                                            <div class="optionBtn d-flex justify-content-center">
                                                <div class="btn-group">
                                                    <a class="btn btn-success" href="<?php echo e(route('addToCart', $product->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
                                                    <button type="button" class="btn btn-success"><i class="fa fa-heart"></i></button>
                                                    <button type="button" class="btn btn-success"><i class="fa fa-eye"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="text-center">
                                            <h4>No Product Available</h4>
                                        </div>
                                    <?php endif; ?>

                                </div>


                                <div class="d-flex justify-content-center">
                                    <?php echo $products->links(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>

<?php /**PATH C:\Laravel\toNote\resources\views/guest/products.blade.php ENDPATH**/ ?>