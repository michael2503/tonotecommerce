<x-guest-layout>
    <section class="breadCrum">
        <div class="container">
            <div class="breacrumCard">
                Welcome to your dashboard
            </div>
        </div>
    </section>
</x-guest-layout>
